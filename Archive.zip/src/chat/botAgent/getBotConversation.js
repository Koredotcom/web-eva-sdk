import { cloneDeep, isEmpty } from "lodash";
import {chatWindow, chatConfig} from "@koredev/kore-web-sdk"
import store from "../../redux/store";
import { checkHistoryAccessed, getCidByMessageId, getReqIdByMessageId } from "../../utils/helpers";
import { updateChatData, setBotSDKInstance, setCurrentQuestion, setEnableKoreBotSDK } from "../../redux/globalSlice";
import { advanceSearch } from "../../redux/actions/global.action";
import { constructQuestionPostCall } from "../chat-utils";
import { setBotInstance, getBotInstance } from "./botSDKManager";
import { setupTemplates } from "../../templateRenderer/templates/bot-conversation";


const BotConversation = (args) => {
    let state = store.getState().global
    let currentBotSDKInstance = getBotInstance();

    const initializeBotSDK = (botDetails) => {
        let botOptions = chatConfig.botOptions;        
        botOptions.JWTUrl = "https://mk2r2rmj21.execute-api.us-east-1.amazonaws.com/dev/users/sts";
        botOptions.userIdentity = state?.profile?.data?.emailId || botDetails?.userEmailId;// Provide users email id here
        botOptions.botInfo = { name: botDetails?.name, "_id": botDetails?.streamId }; // bot name is case sensitive
        botOptions.clientId = botDetails?.webhook?.clientId;
        botOptions.clientSecret = botDetails?.webhook?.clientSecret;
        let botSDKInstance =  new chatWindow(chatConfig)
        if(state?.enableDebugging){
            console.log("bot sdk initialized: ", botSDKInstance)
        }
        currentBotSDKInstance = botSDKInstance
        // store.dispatch(setBotSDKInstance(botSDKInstance))
        setBotInstance(currentBotSDKInstance)
    }      
    if(currentBotSDKInstance){
        currentBotSDKInstance.sendMessage = (msg, renderTxt) => {
            /*
            msg is the payload to be sent to server,
            renderTxt is the object that cotains the data to be rendered at the client application
            */
            if (msg) {
                if(state?.enableDebugging){
                    console.log(msg, renderTxt)
                }
                submitBotResponse({
                    "input": msg,
                    "cId": state?.currentQuestion?.reqId,
                    "messageId": Object.values(store.getState().global?.currentQuestion?.botConversation)?.find(c => c.hasOwnProperty('template_html') && c.status === "in-progress")?.messageId,
                    "context": state?.currentQuestion?.context,
                    "source": "bot",
                    "renderMsgPayload": renderTxt?.renderMsg
                })
            }
        }
    }
    
    const setBotConversation = (detail) => {
        let question;
        let questions = cloneDeep(state?.questions)   
        if (isEmpty(questions)) {
            return;
        }     
        if(detail?.action === "create"){
            question = questions[getReqIdByMessageId(detail?.pId)]
            if (isEmpty(question)) {
                //corresponding bot question is unavailable
                if(state?.enableDebugging){
                    console.error(`bot question with id: ${detail?.messageId} is unavailable, please check the store`)
                }
                return;
            } else {
                if (!question?.hasOwnProperty('botConversation')) {
                    question.botConversation = {}
                }
                question.botConversation[detail?.messageId] = detail?.message
                if (detail?.message?.templateType === "bot_template" || detail?.message?.templateType === "hold_conversation"){
                    if (state.enableKoreBotSDK){                        
                        const templatePayload = {
                            "type": "bot_response",
                            "from": "bot",
                            "messageId": detail?.message?.messageId,
                            "message": [
                                {
                                    "type": "text",
                                    "component": detail?.message?.content
                                }
                            ]
                        }
                        currentBotSDKInstance.chatEle = document.getElementsByClassName(".bot-conversation-wrapper")[0]
                        if(state?.enableDebugging){
                            console.log("template html: ", currentBotSDKInstance.generateMessageDOM(templatePayload))
                        }
                        question.botConversation[detail?.messageId].template_html = currentBotSDKInstance.generateMessageDOM(templatePayload) || new chatWindow().generateMessageDOM(templatePayload)
                    }                    
                }
            }
        }
        if(detail?.action === "update"){         
            /*reqId only comes when updating the parentMessage clo */   
            // if (detail?.message?.hasOwnProperty('reqId') && Object.keys(questions || {}).length > 0) {
            //     const currentQuestion = Object.values(questions).find(ques => ques.reqId === detail.message.reqId)
            //     if(currentQuestion?.historicalData){
            //         question = questions?.[currentQuestion?.id]
            //     }else{
            //         question = questions?.[currentQuestion?.reqId]
            //     }                                
            // }else{
                
            // }     
            if(Object.keys(questions || {}).length === 0){
                return;
            }   
            /*Identify whether to update the question which is inside agentic flow or not
            in case of agentic flow, pId will the main id i.e agentic flow id, so in order to get the bot question we need to check with the messageId
            */               
            question = questions[getReqIdByMessageId(detail?.message?.pId)] /*in order to update the already existing messages of botConversation, we will depend on pId */            
            if(question){//found the question with pId, so need to update the conversation present in botConversation
                /*need to see if it is a agentic flow question or not, if it is a part of agentic flow question, using messageId fetch the key of the questions array to */
                if(question?.executionPipeline?.length){
                    question = questions[getCidByMessageId(questions, detail?.message?.messageId)]
                    question = {...question, 'answer': detail?.message?.answer, 'status': detail?.message?.status, 'reqFlow': detail?.message?.reqFlow}
                }else{
                    question.botConversation[detail?.message?.messageId] = detail?.message
                }                
            }else{
                question = questions[detail?.message?.reqId] /*to update the parent message itself, */
                if(!question){
                    if(state?.enableDebugging){
                        console.error(`bot question with reqId: ${detail?.message?.reqId} is unavailable, please check the store`)
                    }
                    return;
                }             
                question = {...question, 'answer': detail?.message?.answer, 'status': detail?.message?.status}
            }
            
            
            /*should retain the id of the question when accessing from history */
            // if(question?.historicalData){
            //     const questionHistoryId = question.id
            //     question = { ...question, ...detail?.message }
            //     question.id = questionHistoryId
            // }else{
            //     // question = { ...question, ...detail?.message }
            // }  
            if(state?.enableDebugging){
                console.log("question after update: ", question)
            }         
        }       
        if(!question){
            if(state?.enableDebugging){
                console.error(`can't update the question as the question is 'undefined' or 'null' -133`)
            }
            return;
        } 
        store.dispatch(setCurrentQuestion(question))
        /*In case of history data we need to depend on id of the question */
        // if(question?.historicalData){
        //     questions[question?.id] = question
        // }else{
        //     questions[question?.reqId] = question
        // }       
        if(question?.isTask) {
            questions[question?.cId] = question
        }else{
            questions[question?.reqId] = question
        }        
        store.dispatch(updateChatData(questions))        
        setupTemplates(question.botConversation);
    }

    const enableEVABotSdk = (payload) => {
        store.dispatch(setEnableKoreBotSDK(payload))
    }


    const submitBotResponse = async (data) => {
        /**
         * needed payload
         payload = {
         "question": "nothing but used entered answer",
         "context": "current question's context",
         "messageId": "current bot question's messageId"
         "source": "bot"
         }
         */
        state = store.getState().global
        const params = {
            "reqId": data?.cId, //use reqId
            "from": "botAgent"
        }
        let payload = {
            "question": data?.input,
            "context": data?.context,
            "messageId": data?.messageId,
            "source": "bot"
        }
        if (data?.renderMsgPayload){
            payload.renderMsgPayload = data?.renderMsgPayload 
        }
        if (!isEmpty(state.customData)) {
            payload.customData = state.customData
            console.log("custom data in getBotConversation line 165 : ", payload.customData)
        }
        if(state?.enableDebugging){
            console.log("state data: ", state)        
        }
        /*need to add a loading state for the current question */
        console.log("custom data in getBotConversation line 167 : ", payload.customData)
        addLoadingStateToCurrentQuestion(data?.cId, data?.messageId, data?.input)
        if(state?.enableDebugging){
            console.log("params data: ", data)
        }
        console.log("custom data in getBotConversation line 171 : ", payload?.customData)
        setTimeout(() => {
            const conversation = Object.values(state?.questions)?.find(c => c?.reqId === data?.cId)?.botConversation?.[data?.messageId]
            
            const scrollToTarget = document.getElementById(conversation?.messageId) 
            if (scrollToTarget) {
                scrollToTarget.scrollIntoView({behavior: "smooth" , block: "start"});
            }
        }, 1000);
        const res = await store.dispatch(advanceSearch({ params, payload, userId: state?.profile?.data?.id || data?.userId}))
        console.log("custom data in getBotConversation line 173 : ", payload?.customData)
        constructQuestionPostCall(res, data?.cId)
    }

    const addLoadingStateToCurrentQuestion = (quesReqId, messageId, input) => {
        let reqId = quesReqId
        let questions = cloneDeep(state?.questions)
        const isHistoryAccessed = checkHistoryAccessed(questions)
        if(isHistoryAccessed){
            reqId = Object.entries(questions).find(([key, value]) => value?.reqId === reqId)?.[0]
        }
        let currentQuestion = questions[reqId]
        if (currentQuestion) {
            let botConversation = currentQuestion?.botConversation
            if (botConversation) {
                let currentBotQuestion = botConversation?.[messageId]
                if (currentBotQuestion) {                    
                    currentBotQuestion.loading = true
                    currentBotQuestion.answer = input
                    if(state?.enableDebugging){
                        console.log("added loading state: ", currentBotQuestion)
                    }
                    botConversation[messageId] = currentBotQuestion
                    currentQuestion.botConversation = botConversation
                    questions[reqId] = currentQuestion                    
                    store.dispatch(updateChatData(questions))
                }
            }
        }
    }
    const installOwnTemplate = (templateInstance) => {
        currentBotSDKInstance?.templateManager?.installTemplate(templateInstance) //Here templateInstance should be a component
    }

    const generateHTMLforBotTemplate = (templatePayload) => {        
        const xoTemplatePayload = {
            "type": "bot_response",
            "from": "bot",
            "messageId": templatePayload?.messageId,
            "message": [
                {
                    "type": "text",
                    "component": templatePayload?.content
                }
            ]
        }
        currentBotSDKInstance.chatEle = document.getElementById("chatTestComp")
        return currentBotSDKInstance.generateMessageDOM(xoTemplatePayload)
        
    }
    return{
        setBotConversation,
        submitBotResponse,
        installOwnTemplate,
        initializeBotSDK,
        enableEVABotSdk,
        generateHTMLforBotTemplate
    }
}

export default BotConversation;